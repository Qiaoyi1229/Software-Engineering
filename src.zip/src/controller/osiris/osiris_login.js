
import axios from 'axios'
import SIdentify from '../../components/osiris/osiris_login_verify_code.vue'

export default {
    name: 'OsirisLogin',
    components: {
        SIdentify
    },
    props: {
    },
    data: function() {
        return {
            form: {},
            regForm: {},
            showRegUserModal: false,

            identifyCodes: '1234567890',
            identifyCode: '',

            avatarUrl: "",
            avatarFile: null,
        }
    },
    methods: {
        loginOnClick() {

            var options = this.form;

            if (!options.name) {
                this.$message({
                    message: '请输入用户名',
                    type: 'warning'
                });
                return;
            }

            if (!options.password) {
                this.$message({
                    message: '请输入密码',
                    type: 'warning'
                });
                return;
            }

            if (!options.verifycode) {
                this.$message({
                    message: '请输入验证码',
                    type: 'warning'
                });
                return;
            }

            if (options.verifycode != this.identifyCode) {
                this.$message({
                    message: '验证码不正确',
                    type: 'warning'
                });
                return;
            }

            options['role'] = 1;
            
            this.loginUser(options);
        },
        loginUser(options) {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/user/login",
                params: options,
            }).then(function(data) {

                if (data.data.msg == '登录失败') {
                    self.$message({
                        message: '用户名或密码不正确',
                        type: 'warning'
                    });
                    self.refreshCode();
                } else {
                    self.$notify({
                        title: '登录成功',
                        message: '欢迎使用XXX',
                        type: 'success'
                    });

                    if (data.data.data) {
                        var userObj = data.data.data
                        for (var key in userObj) {
                            sessionStorage.setItem(key, userObj[key]);
                        }
                    }

                    self.$router.push("/");
                }

            }).catch(function (error) {
                self.$message.error('登录失败');
                self.refreshCode();
                console.log(error);
            });
        },



        randomNum(min, max) {
            return Math.floor(Math.random() * (max - min) + min)
        },
        refreshCode() {
            this.identifyCode = ''
            this.makeCode(this.identifyCodes, 4)
        },
        makeCode(o, l) {
            for (let i = 0; i < l; i++) {
                this.identifyCode += this.identifyCodes[
                this.randomNum(0, this.identifyCodes.length)
                ]
            }
        },




        openRegOnClick() {
            this.regForm = {},
            this.avatarUrl = "",
            this.avatarFile = null,

            this.showRegUserModal = true;
        },
        regUserOnClick() {

            var options = this.regForm;

            if (!options.name) {
                this.$message({
                    message: '请输入用户名',
                    type: 'warning'
                });
                return;
            }

            if (!options.password) {
                this.$message({
                    message: '请输入密码',
                    type: 'warning'
                });
                return;
            }

            if (!options.passwordConfirm) {
                this.$message({
                    message: '请确认密码',
                    type: 'warning'
                });
                return;
            }

            if (options.password != options.passwordConfirm) {
                this.$message({
                    message: '密码不一致',
                    type: 'warning'
                });
                return;
            }

            if (!this.avatarFile) {
                this.$message({
                    message: '请上传头像',
                    type: 'warning'
                });
                return;
            }

            options['file'] = this.avatarFile;
            options['role'] = 1;

            this.regUser(options);
        },
        regUser(options) {

            var self = this;

            var formData = new FormData();
            for (var key in options) {
                formData.append(key, options[key]);
            }

            let config = {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }

            axios.post("/api/v1/film/user/reg", formData, config
            ).then( res => {
                if (res.data.msg == '用户名存在') {
                    self.$message.error('用户名存在');
                } else {
                    self.$message({
                        message: '注册成功',
                        type: 'success'
                    });
                    self.showRegUserModal = false;
                }
            }).catch( res => {
                self.$message.error('注册失败');
                console.log(res)
            });
        },


        handleAvatarSuccess(res, file) {
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        beforeAvatarUpload(file) {

            const isJPG = file.type === 'image/jpeg';
            const isLt2M = file.size / 1024 / 1024 < 2;

            if (!isJPG) {
                this.$message.error('上传头像图片只能是 JPG 格式!');
            }
            if (!isLt2M) {
                this.$message.error('上传头像图片大小不能超过 2MB!');
            }
            return isJPG && isLt2M;
        },
        httpRequest (data) {
            var self = this;
            var rd = new FileReader();
            var file = data.file;
            rd.readAsDataURL(file);
            rd.onloadend = function () {
                self.avatarUrl = this.result;
                self.avatarFile = file;
            }
        },
    },
    mounted: function() {
        this.refreshCode();
    }
}