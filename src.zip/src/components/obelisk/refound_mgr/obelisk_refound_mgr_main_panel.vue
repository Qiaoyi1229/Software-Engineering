<template>
  <div>
      RefoundMgr
  </div>
</template>
<script src="../../../controller/obelisk/refound_mgr/obelisk_refound_mgr_main_panel.js"></script>
