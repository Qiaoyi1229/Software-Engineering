import axios from 'axios'

import ObeliskUserMgrCreateModal from "../../../components/obelisk/user_mgr/obelisk_user_mgr_create_modal.vue"

export default {
    name: 'ObeliskUserMgrMainPanel',
    components: {
        ObeliskUserMgrCreateModal,
    },
    props: {
        
    },
    data: function() {
        return {
            test: 2,
            userArray: [],
        }
    },
    methods: {
        init() {
            this.fetchAllUser();
        },
        formatSex(row) {
            return row.sex === 1 ? '男' : row.sex === 0 ? '女' : '未知';
        },
        formatTime(row) {
            return new Date(row.createTime).Format('yyyy-MM-dd hh:mm:ss');
        },
        userDeleteOnClick(row) {
            this.$confirm('确认删除用户：' + row.name, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.deleteUser(row.id);
            });
        },
        userUpdateOnClick(row) {
            this.$refs.createModal.openUserCreateModal(row);
        },
        fetchAllUser() {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/user/findAll",
                params: {}
            }).then(function(data) {
                if (data.data.data) {
                    self.userArray = data.data.data;
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        deleteUser(id) {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/user/delete",
                params: {
                    "id": Number(id),
                }
            }).then(function(data) {
                if (data.data.data) {
                    self.userArray = data.data.data;
                    self.$message({
                        message: '删除用户成功',
                        type: 'success'
                    });
                }
            }).catch(function (error) {
                self.$message.error('删除用户失败');
                console.log(error);
            });
        },
        updateUser(user) {

            var self = this;

            var options = user;
            options['age'] = Number(options['age']);
            options['sex'] = Number(options['sex']);

            axios({
                method: 'post',
                url: "/api/v1/film/user/update",
                params: options,
            }).then(function(data) {
                if (data.data.data) {
                    self.userArray = data.data.data;
                    self.$message({
                        message: '修改用户成功',
                        type: 'success'
                    });
                }
            }).catch(function (error) {
                self.$message.error('修改用户失败');
                console.log(error);
            });
        }
    },
    mounted: function() {

        this.init();

        Date.prototype.Format = function (fmt) {
            var o = {
                "M+": this.getMonth() + 1, 
                "d+": this.getDate(), 
                "h+": this.getHours(),
                "m+": this.getMinutes(),
                "s+": this.getSeconds(),
                "q+": Math.floor((this.getMonth() + 3) / 3),
                "S": this.getMilliseconds()
            };
            if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            for (var k in o)
                if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            return fmt;
        };
    }
}