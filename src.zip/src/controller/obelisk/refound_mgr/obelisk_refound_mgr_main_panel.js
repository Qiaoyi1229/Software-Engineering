export default {
    name: 'ObeliskRefoundMgrMainPanel',
    props: {
    },
    data: function() {
        return {
            test: 3,
        }
    }
}