<template>
  <div>
      <div class="seachMovieBox">
      </div>

      <el-row v-for="(movieArray, index) of movieArrayForTable" :key="index" class="showMovieRow">
        <el-col :span="row_span" v-for="movie of movieArray" :key="movie.name">
          <el-card class="showMovieCard" shadow="hover" @click.native="movieOnClick(movie)">
            <img :src="getMovieImgUrl(movie.image)" class="movieCardImage">
            <p class="movieInfoP">{{ movie.name }}</p>
            <p class="movieInfoP">上映时间：{{ formatTime(movie.releaseTime) }}</p>
          </el-card>
        </el-col>
      </el-row>

  </div>
</template>
<style>
  .showMovieCard {
    width: 300px;
    height: 300px;
    text-align: center;
  }
  .showMovieCard:hover {
    cursor: pointer;
  }
  .movieCardImage {
    margin: 0 auto;
    max-width: 300px;
    max-height: 150px;
    display: block;
  }
  .movieInfoP {
    margin-top: 25px;
    font-size: 20px;
  }
  .showMovieRow {
    margin-top: 30px;
  }
</style>
<script src="../../../controller/osiris/show_movie/osiris_show_movie.js"></script>
