<template>
  <div>

    <el-dialog title="创建排片" :visible.sync="showArrangeUpdateModal">
      <el-form label-width="100px" :model="form">
        <el-form-item label="电影：">
          
          <el-select v-model="form.filmId" placeholder="请选择电影">
            <el-option
              v-for="item in movie_array"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>

        </el-form-item>
        <el-form-item label="大厅：">

          <el-select v-model="form.hallId" placeholder="请选择大厅">
            <el-option
              v-for="item in hall_array"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>

        </el-form-item>
        <el-form-item label="票价：">
          <el-input v-model="form.price" autocomplete="off" style="width: 90%"></el-input>
        </el-form-item>

        <el-form-item label="开始时间：">

          <el-date-picker
            v-model="form.startTime"
            type="datetime"
            placeholder="请选择电影开始时间">
          </el-date-picker>

        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showArrangeUpdateModal = false">取 消</el-button>
        <el-button type="primary" @click="updateArrangeOnClick()">创 建</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<style>
</style>
<script src="../../../controller/obelisk/seat_mgr/obelisk_seat_mgr_create_modal.js"></script>
