<template>
  <div class="arrangeMovieWrapper">

    <el-table
      :data="curMovieArrangeArray"
      @row-click="arrangeRowOnClick"
      empty-text="暂无排片"
      style="width: 100%">

      <el-table-column
        width="350"
        prop="startTime"
        label="开场时间">
      </el-table-column>
      
      <el-table-column
        width="300"
        prop="filmName"
        label="电影">
      </el-table-column>

      <el-table-column
        width="300"
        prop="hallName"
        label="大厅">
      </el-table-column>

      <el-table-column
        width="80"
        prop="price"
        label="票价">
      </el-table-column>

    </el-table>

  </div>
</template>
<style>
  .arrangeMovieWrapper .el-table__row:hover {
    cursor: pointer;
  }
</style>
<script src="../../../controller/osiris/arrange_movie/osiris_arrange_movie.js"></script>
