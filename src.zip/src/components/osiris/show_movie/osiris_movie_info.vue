<template>
  <div>

    <el-container>


      <el-header>
        <div class="pageHead">
          <h1>XXXX</h1>
        </div>

        <div class="userAvatarBox">
          <el-avatar :src="curUserImgUrl"
            icon="el-icon-user-solid userAvatar" @click.native="userAvatarOnClick()"></el-avatar>
        </div>

        <el-menu :default-active="mainMenuActiveIndex" class="mainMenu" mode="horizontal" @select="handleMainMenuSelect">
          <el-menu-item index="1">主页</el-menu-item>
          <el-menu-item index="2">影片</el-menu-item>
          <el-menu-item index="3">影院</el-menu-item>
        </el-menu>
      </el-header>



      <el-main>

        <div class="movieBackImgBox">
        </div>
        <div class="movieInfoBoxPage">
          
          <el-image
            class="movieInfoImg"
            :src="'http://' + this.global.BASE_URL + this.curMovieObj.image">
          </el-image>

          <div class="movieNameBox">
            {{ curMovieObj.name }}
          </div>

          <div class="movieInfoText">
            <el-row class="movieInfoRow">
              <el-col :span="4">
                导演：{{ curMovieObj.director }}
              </el-col>
              <el-col :span="4">
                主演：{{ curMovieObj.actor }}
              </el-col>
              <el-col :span="4">
                类型：{{ curMovieObj.typeName }}
              </el-col>
              <el-col :span="5">
                制片国家/地区：{{ curMovieObj.areaName }}
              </el-col>
            </el-row>
            <el-row class="movieInfoRow">
              <el-col :span="6">
                上映时间：{{ dateToString(curMovieObj.createTime) }}
              </el-col>
              <el-col :span="4">
                片长：{{ curMovieObj.length }}分钟
              </el-col>
              <el-col :span="12">
                剧情介绍：{{ curMovieObj.details }}
              </el-col>
            </el-row>
          </div>

        </div>
        <div class="arrangeMovieBox">

          <div class="arrangeTitleBox">
            当前排片
          </div>

          <OsirisArrangeMovie />
        </div>

      </el-main>
      
      
      
      <el-footer></el-footer>
    </el-container>

  </div>
</template>
<style>
  .movieBackImgBox {
    width: 100%;
    height: 400px;
    filter: brightness(0.4) blur(7px);
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: 200%;  
    background-position:center;
    position: relative;
  }
  .movieInfoBoxPage {
    position: relative;
    width: 100%;
    height: 320px;
    top: -380px;
  }
  .arrangeMovieBox {
    margin-top: -175px;
    margin-left: auto;
    margin-right: auto;
    width: 70%;
  }
  .movieInfoImg {
    max-width: 400px;
    max-height: 200px;
    position: absolute;
    margin-left: 150px;
    margin-top: 30px;
  }
  .movieNameBox {
    position: absolute;
    margin-left: 1200px;
    margin-top: 120px;
    color: #FFF;
    font: 50px Extra large sans-serif;
  }

  .arrangeTitleBox {
    margin-top: -90px;
    position: absolute;
    font: 50px Extra large sans-serif;
    z-index: 1;
  }

  .movieInfoText {
    margin-top: 260px;
    position: absolute;
    color: #FFF;
    width: 60%;
    height: 100%;
    margin-left: 150px;
  }

  .movieInfoRow {
    margin-bottom: 20px;
  }
</style>
<script src="../../../controller/osiris/show_movie/osiris_movie_info.js"></script>
