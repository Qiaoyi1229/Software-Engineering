export default {
    name: 'ObeliskMovieMgrCreateModal',
    props: {
        type_array: {
            type: Array,
            required: true,
            default: [],
        },
        area_array: {
            type: Array,
            required: true,
            default: [],
        }
    },
    data: function() {
        return {
            showMovieUpdateModal: false,
            form: {},

            imageUrl: '',
            imageFile: null,
        }
    },
    methods: {
        openMovieCreateModal() {
            this.form = {};
            this.imageUrl = '';
            this.imageFile = null;
            
            this.showMovieUpdateModal = true;
        },
        closeMovieCreateModal() {
            this.form = {};
            this.imageUrl = '';
            this.imageFile = null;

            this.showMovieUpdateModal = false;
        },
        updateMovieOnClick() {

            var options = this.form;

            if (!options.name || options.name == "") {
                this.$message({
                    message: '请输入电影名称',
                    type: 'warning'
                });
                return;
            }

            if (!options.director || options.director == "") {
                this.$message({
                    message: '请输入导演',
                    type: 'warning'
                });
                return;
            }

            if (!options.actor || options.actor == "") {
                this.$message({
                    message: '请输入主演',
                    type: 'warning'
                });
                return;
            }

            if (!options.length || options.length == "") {
                this.$message({
                    message: '请输入时长',
                    type: 'warning'
                });
                return;
            }

            if (!options.details || options.details == "") {
                this.$message({
                    message: '请输入备注',
                    type: 'warning'
                });
                return;
            }
            
            if (!options.typeId) {
                this.$message({
                    message: '请选择电影类型',
                    type: 'warning'
                });
                return;
            }

            if (!options.areaId) {
                this.$message({
                    message: '请选择电影地区',
                    type: 'warning'
                });
                return;
            }

            if (!options.releaseTime) {
                this.$message({
                    message: '请选择发行日期',
                    type: 'warning'
                });
                return;
            }

            if (!this.imageFile) {
                this.$message({
                    message: '请上传电影图片',
                    type: 'warning'
                });
                return;
            }

            options['file'] = this.imageFile

            this.$emit("add_movie", options);
        },

        handleAvatarSuccess(res, file) {
            this.imageUrl = URL.createObjectURL(file.raw);
        },
        beforeAvatarUpload(file) {

            const isJPG = file.type === 'image/jpeg';
            const isLt2M = file.size / 1024 / 1024 < 2;

            if (!isJPG) {
                this.$message.error('上传头像图片只能是 JPG 格式!');
            }
            if (!isLt2M) {
                this.$message.error('上传头像图片大小不能超过 2MB!');
            }
            return isJPG && isLt2M;
        },
        httpRequest (data) {
            var self = this;
            var rd = new FileReader();
            var file = data.file;
            rd.readAsDataURL(file);
            rd.onloadend = function () {
                self.imageUrl = this.result;
                self.imageFile = file;
            }
        },
    },
    mounted: function() {
    }
}