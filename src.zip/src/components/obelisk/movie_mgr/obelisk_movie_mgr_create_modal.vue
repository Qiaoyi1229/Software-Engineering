<template>
  <div>
    
    <el-dialog title="添加电影" :visible.sync="showMovieUpdateModal">
      <el-form label-width="100px" :model="form">


        <el-row>
          <el-col :span="11">
            <el-form-item label="电影名">
              <el-input v-model="form.name" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="11">
            <el-form-item label="导演">
              <el-input v-model="form.director" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        

        <el-row>
          <el-col :span="11">
            <el-form-item label="主演">
              <el-input v-model="form.actor" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="11">
            <el-form-item label="时长">
              <el-input v-model="form.length" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        
        <el-row>
          <el-col :span="22">
            <el-form-item label="备注">
              <el-input v-model="form.details" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>


        <el-row>
          <el-col :span="11">
            <el-form-item label="类型">
              <el-select v-model="form.typeId" placeholder="请选择电影类型">
                <el-option
                  v-for="item in type_array"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="11">
            <el-form-item label="地区">
              <el-select v-model="form.areaId" placeholder="请选择电影地区">
                <el-option
                  v-for="item in area_array"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>


        <el-row>
          <el-col :span="11">
            <el-form-item label="发行日期">
              <el-date-picker
                v-model="form.releaseTime"
                type="date"
                placeholder="选择日期">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>


        <el-row>
          <el-col :span="11">
            <el-form-item label="上传图片">
              <el-upload
                class="avatar-uploader"
                action="#"
                :http-request="httpRequest"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img v-if="imageUrl" :src="imageUrl" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
            </el-form-item>
          </el-col>
        </el-row>


      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showMovieUpdateModal = false">取 消</el-button>
        <el-button type="primary" @click="updateMovieOnClick()">添 加</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
<script src="../../../controller/obelisk/movie_mgr/obelisk_movie_mgr_create_modal.js"></script>
