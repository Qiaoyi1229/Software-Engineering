<template>
  <div class="loginBack">

    <el-form ref="loginForm" :model="form" label-width="80px" class="login-box">
      <h3 class="login-title">欢迎登录</h3>
      <el-form-item label="账号" prop="username">
        <el-input type="text" placeholder="请输入账号" v-model="form.name"/>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input type="password" placeholder="请输入密码" v-model="form.password"/>
      </el-form-item>
      <el-form-item label="验证码" prop="verifycode">
        <el-input type="text" placeholder="请输入验证码" v-model="form.verifycode"/>
      </el-form-item>
      <el-form-item>
        <div class="identifybox">
          <div @click="refreshCode">
            <s-identify :identifyCode="identifyCode"></s-identify>
          </div>
          <el-button @click="refreshCode" type='text' class="textbtn">看不清，换一张</el-button>
        </div>
      </el-form-item>
      <el-form-item style="margin-top: 30px">
        <el-button style="margin-left: 40px" type="primary" @click="loginOnClick()">登录</el-button>
        <el-link style="margin-left: 15px" type="primary" @click="openRegOnClick()">注册</el-link>
      </el-form-item>
    </el-form>

    <el-dialog title="注册" :visible.sync="showRegUserModal">
      <el-form label-width="100px" :model="regForm">

        <el-row>
          <el-col :span="22">
            <el-form-item label="用户名">
              <el-input v-model="regForm.name" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        
        <el-row>
          <el-col :span="11">
            <el-form-item label="密码">
              <el-input v-model="regForm.password" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="11">
            <el-form-item label="确认密码">
              <el-input v-model="regForm.passwordConfirm" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="11">
            <el-form-item label="邮箱">
              <el-input v-model="regForm.mail" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="11">
            <el-form-item label="电话">
              <el-input v-model="regForm.phone" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="11">
            <el-form-item label="年龄">
              <el-input v-model="regForm.age" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="11">
            <el-form-item label="上传头像">
              <el-upload
                class="avatar-uploader"
                action="#"
                :http-request="httpRequest"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img v-if="avatarUrl" :src="avatarUrl" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
            </el-form-item>
          </el-col>
        </el-row>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showRegUserModal = false">取 消</el-button>
        <el-button type="primary" @click="regUserOnClick()">注 册</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<style>
  .loginBack {
    position: absolute;
    width: 100%;
    height: 100%;
    background-image: url(../../assets/c_1.jpg);
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: 100%;  
    background-position:center;  
  }

 .login-box {
    border: 1px solid #DCDFE6;
    width: 350px;
    margin: 100px auto;
    padding: 35px 35px 15px 35px;
    background: white;
    border-radius: 5px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    box-shadow: 0 0 25px #909399;
  }
  .login-title {
    text-align: center;
    margin: 0 auto 40px auto;
    color: #303133;
  }
</style>
<script src="../../controller/osiris/osiris_login.js"></script>