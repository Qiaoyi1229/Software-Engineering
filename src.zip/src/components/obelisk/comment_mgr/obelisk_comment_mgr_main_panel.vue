<template>
  <div>
      CommentMgr
  </div>
</template>
<script src="../../../controller/obelisk/comment_mgr/obelisk_comment_mgr_main_panel.js"></script>
