<template>
  <div>
      <div class="seachMovieBox">
        <el-select v-model="searchInfo.typeId" placeholder="请选择电影类型">
          <el-option
            v-for="item in mTypeArray"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>

        <el-select v-model="searchInfo.areaId" placeholder="请选择电影地区">
          <el-option
            v-for="item in mAreaArray"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>

        <div style="float: right">
          <el-button type="primary" @click="seachMovieByTypeAndArea()">搜索</el-button>
        </div>
      </div>



      <el-card class="movieCard" shadow="hover" @click.native="movieCardOnClick(film)"
              v-for="(film, index) in filmArray" v-bind:key="index">
        <el-image
          style="width: 200px; height: 200px"
          :src="'http://' + imgUrlRoot + film.image"
          fit="contain">
        </el-image>

        <div class="movieInfoBox">
          <el-row class="movieInfoRow">
            <el-col :span="11">
              名称：{{ film.name }}
            </el-col>
            <el-col :span="11">
              导演：{{ film.director }}
            </el-col>
          </el-row>
          <el-row class="movieInfoRow">
            <el-col :span="11">
              主演：{{ film.actor }}
            </el-col>
            <el-col :span="11">
              时长：{{ film.length }} min
            </el-col>
          </el-row>
          <el-row class="movieInfoRow">
            <el-col :span="22">
              备注：{{ film.details }}
            </el-col>
          </el-row>
          <el-row class="movieInfoRow">
            <el-col :span="11">
              类型：{{ mTypeMap[film.typeId] || film.typeId }}
            </el-col>
            <el-col :span="11">
              地区：{{ mAreaMap[film.areaId] || film.areaId }}
            </el-col>
          </el-row>
          <el-row class="movieInfoRow">
            <el-col :span="22">
              发行日期：{{ film.releaseTime }}
            </el-col>
          </el-row>
        </div>
        

      </el-card>


      <el-card class="movieCard" style="text-align: center;" v-if="filmArray.length == 0" shadow="hover">
        暂无内容
      </el-card>



      <el-card class="movieInsertIconBox" shadow="hover" @click.native="addMovieOnClick()">
        <i class="el-icon-circle-plus-outline insertMovieIcon"></i>
      </el-card>

      <el-dialog
        :visible.sync="showMovieOperateModal"
        width="30%"
        center>
        <el-form style="text-align: center">
          <el-button type="danger" @click="deleteMovieOnClick()">删除电影</el-button>
          <el-button type="primary" @click="updateMovieOnClick()">修改电影</el-button>
        </el-form>
      </el-dialog>

      <ObeliskMovieMgrCreateModal 
        ref="createModal"
        :type_array="mTypeArray"
        :area_array="mAreaArray"
        @add_movie="addMovie" />

  </div>
</template>
<style>
  .movieCard {
    width: 80%;
    margin: 0 auto;
    margin-top: 40px;
    cursor: pointer;
  }
  .movieInsertIconBox {
    width: 80%;
    margin: 0 auto;
    font-size: 35px;
    margin-top: 30px;
    text-align: center;
  }
  .movieInsertIconBox:hover {
    cursor: pointer;
  }
  .seachMovieBox {
    width: 80%;
    margin: 0 auto;
  }
  .movieInfoBox {
    float: right;
    width: 70%;
  }
  .movieInfoRow {
    margin-bottom: 20px;
  }
</style>
<script src="../../../controller/obelisk/movie_mgr/obelisk_movie_mgr_main_panel.js"></script>
