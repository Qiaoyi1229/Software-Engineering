<template>
  <div>
    <div class="stepButtonBox">
      <el-button class="stepAheadButton" @click="stepAheadButtonOnClick()">上一步</el-button>
      <el-button class="stepNextButton" @click="stepNextButtonOnClick()">下一步</el-button>
    </div>
    <el-steps :space="800" :active="curSetp" finish-status="success" class="stepBox">
      <el-step title="选座"></el-step>
      <el-step title="付款"></el-step>
    </el-steps>

    <div class="allSeatBox" v-show="curSetp == 0">

      <div class="screenIcon">屏幕</div>

      <el-row v-for="rowIndex of 10" :key="rowIndex" style="margin-bottom: 10px;">
        <el-col :span="1">{{ rowIndex }}</el-col>
        <el-col :span="1" v-for="colIndex of 10" :key="colIndex">
          <div class="seatIcon"
              :class="{ 'seatSelected' : isSeatSelect(rowIndex, colIndex),
                        'seatDisabled' : isSeatDisabled(rowIndex, colIndex)}"
              @click="seatOnClick(rowIndex, colIndex)">{{ colIndex }}</div>
        </el-col>
      </el-row>

      <div class="seatlegendBox">
        <div class="seatIcon" style="margin: 0 auto"></div>
        未选择
      </div>
      <div class="seatlegendBox">
        <div class="seatIcon seatSelected" style="margin: 0 auto"></div>
        已选择
      </div>
      <div class="seatlegendBox">
        <div class="seatIcon seatDisabled" style="margin: 0 auto"></div>
        不可选
      </div>
    </div>

    <div class="orderInfoBox" v-show="curSetp == 1">

      <el-row class="orderInfoRow">
        <el-col>影片：{{ curArrange.filmName }}</el-col>
      </el-row>
      <el-row class="orderInfoRow">
        <el-col>时间：{{ curArrange.startTime }}</el-col>
      </el-row>
      <el-row class="orderInfoRow">
        <el-col v-html="getCurSeatStr()"></el-col>
      </el-row>
      <el-row class="orderInfoRow">
        <el-col>票数：{{ curSeatCodn.length }}</el-col>
      </el-row>
      <el-row class="orderInfoRow">
        <el-col>总计：￥{{ curArrange.price * curSeatCodn.length }}</el-col>
      </el-row>

      <el-button type="success" class="orderPayButton" @click="payOnClick()">确认付款</el-button>

    </div>

  </div>
</template>
<style>
  .stepButtonBox {
    position: absolute;
    margin-left: 20%;
    width: 61.5%;
    z-index: 5;
  }
  .stepAheadButton {
    float: left;
  }
  .stepNextButton {
    float: right;
  }

  .stepBox {
    padding-left: 33%;
    margin-bottom: 40px;
    margin-top: 40px;
  }

  .allSeatBox {
    width: 380px;
    margin: 0 auto;
  }

  .allSeatBox .el-col-1 {
    width: 9%;
  }

  .screenIcon {
    float: right;
    width: 360px;
    height: 20px;
    background: rgb(219, 219, 219);
    text-align: center;
    line-height: 20px;
    border-radius: 0 0 8px 8px;
    margin-bottom: 60px;
  }

  .seatIcon {
    width: 30px;
    height: 30px;
    text-align: center;
    border-radius: 5px;
    line-height: 30px;
    color: #fff;
    background: rgb(219, 219, 219);;
  }
  .seatIcon:hover {
    cursor: pointer;
  }
  .seatSelected {
    background: rgb(16, 163, 60);
  }
  .seatDisabled {
    background: rgb(71, 6, 19);
  }

  .seatlegendBox {
    width: 50px;
    float: left;
    margin-left: 60px;
    margin-top: 20px;
  }

  .orderInfoBox {
    width: 380px;
    margin: 0 auto;
  }

  .orderInfoRow {
    margin-bottom: 30px;
  }
  .orderPayButton {
    margin-left: 35%;
  }
</style>
<script src="../../../controller/osiris/movie_order/osiris_movie_order.js"></script>
