package com.six.movie.controller;

public class MovieController   {
}
