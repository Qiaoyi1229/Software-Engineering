package com.example.film.service;

import com.example.film.doo.TimeTableDo;
import com.example.film.dto.req.TimeTableReq;
import com.example.film.entity.TimeTable;

import java.util.List;

/**
 * @author 匡婷
 * @version 1.0
 * @date 2020/3/11 22:23
 */
public interface TimeTableService {

    List<TimeTableDo> findByModel(TimeTableReq timeTableReq);

    Integer insert(TimeTable timeTable);

    Integer update(TimeTable timeTable);

    Integer delete(Integer id);
}
