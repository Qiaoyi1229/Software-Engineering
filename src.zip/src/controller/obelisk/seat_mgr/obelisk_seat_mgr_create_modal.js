export default {
    name: 'ObeliskSeatMgrCreateModal',
    props: {
        movie_array: {
            type: Array,
            required: true,
            default: [],
        },
        hall_array: {
            type: Array,
            required: true,
            default: [],
        }
    },
    data: function() {
        return {
            showArrangeUpdateModal: false,

            form: {}
        }
    },
    methods: {
        openArrangeCreateModal() {
            this.form = {};
            this.showArrangeUpdateModal = true;
        },
        updateArrangeOnClick() {

            var options = this.form;

            if (!options.filmId) {
                this.$message({
                    message: '请选择电影',
                    type: 'warning'
                });
                return;
            }

            if (!options.hallId) {
                this.$message({
                    message: '请选择大厅',
                    type: 'warning'
                });
                return;
            }

            if (options.price == "" || isNaN(options.price)) {
                this.$message({
                    message: '请输入正确的票价',
                    type: 'warning'
                });
                return;
            }

            if (!options.startTime) {
                this.$message({
                    message: '请选择开始时间',
                    type: 'warning'
                });
                return;
            }

            options.price = Number(options.price);
            options.startTime = new Date(options.startTime);

            this.$emit("add_arrange", options);
            this.showArrangeUpdateModal = false;
        }
    },
    mounted: function() {
    }
}