package com.six.movie.query;

import lombok.Data;

@Data
public class UserQuery {
    private Integer userId;
    private String userName;
    private String passWord;
    private String realName;
    private String phone;
    private String email;
    private String createDate;
    private String updateDate;
    private String headImage;
}
