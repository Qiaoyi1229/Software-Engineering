package com.six.movie.mapper;

import com.six.movie.entity.User;
import com.six.movie.query.UserQuery;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {

    User selectUserByPassword(String userName);

    Long selectUserIdByUserName(String userName);

    void addUser(UserQuery query);

    Integer updateUser(UserQuery query);

    String selectPwdByUserId(Integer userId);

    Integer modifyUserPwd(Integer userId, String newPwd);

    List<Map<String, Object>> selectAllUser();
}
