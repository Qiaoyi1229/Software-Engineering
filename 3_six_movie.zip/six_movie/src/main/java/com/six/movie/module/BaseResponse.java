package com.six.movie.module;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseResponse<T> {

    @ApiModelProperty(value = "返回码")
    int code;


    @ApiModelProperty(value = "返回消息")
    String message;

    @ApiModelProperty(value = "返回数据")
    T data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public BaseResponse(T data){
        this(200,"成功", data );
    }

    public BaseResponse()  {
        this("成功",null);
    }

    public BaseResponse(int code, String message) {
        this(code, message, null);
    }

    public BaseResponse(String message) {
        this(500, message, null);
    }

    public BaseResponse(String message, T data) {
        this(200, message, data);
    }

    public BaseResponse(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }
}
