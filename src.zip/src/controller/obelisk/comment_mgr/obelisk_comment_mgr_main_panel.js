export default {
    name: 'ObeliskCommentMgrMainPanel',
    props: {
    },
    data: function() {
        return {
            test: 3,
        }
    }
}