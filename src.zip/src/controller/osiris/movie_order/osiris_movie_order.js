import axios from 'axios'

export default {
    name: 'OsirisMovieOrder',
    components: {
    },
    props: {
    },
    data: function() {
        return {
            curArrange: {},
            curSeatCodn: [],
            curDisabledSeatCodn: [],
            curSetp: 0,
        }
    },
    watch: {
    },
    methods: {
        seatOnClick(row, col) {

            if (this.isSeatDisabled(row, col)) {
                return;
            }

            var seatCodn = row+"*"+col;
            if (this.curSeatCodn.indexOf(seatCodn) == -1) {
                this.curSeatCodn.push(seatCodn);
            } else {
                this.removeByVal(this.curSeatCodn, seatCodn);
            }
        },
        removeByVal(arrylist , val) {
            for(var i = 0; i < arrylist .length; i++) {
                if(arrylist [i] == val) {
                    arrylist .splice(i, 1);
                    break;
                }
            }
        },
        isSeatSelect(row, col) {
            var seatCodn = row+"*"+col;
            if (this.curSeatCodn.indexOf(seatCodn) != -1) {
                return true;
            } else {
                return false;
            }
        },
        isSeatDisabled(row, col) {
            var seatCodn = row+"*"+col;
            if (this.curDisabledSeatCodn.indexOf(seatCodn) != -1) {
                return true;
            } else {
                return false;
            }
        },
        stepAheadButtonOnClick() {
            if (this.curSetp == 0) {
                return;
            }
            if (this.curSetp > 0) {
                this.curSetp--;
            }
        },
        stepNextButtonOnClick() {
            if (this.curSetp == 1) {
                return;
            }
            if (this.curSetp < 1) {
                if (this.curSeatCodn.length == 0) {
                    this.$message({
                        message: '请选择座位',
                        type: 'warning'
                    });
                    return;
                }
                this.curSetp++;
            }
        },

        getCurSeatStr() {
            var str = "";
            for (var seat of this.curSeatCodn) {
                var seatArray = seat.split('*')
                str += seatArray[0] + "排" + seatArray[1] + "座" + "&nbsp;&nbsp;";
            }
            return  "座位：" + str
        },
        payOnClick() {

            var self = this;

            if (!sessionStorage.getItem("id")) {
                this.$message({
                    message: '请登录',
                    type: 'warning'
                });
                this.$router.push("/login");
            }

            if (!self.$route.query.aId) {
                this.$router.push("/");
            }

            var options = {
                "userId": Number(sessionStorage.getItem("id")),
                "timeId": Number(self.$route.query.aId),
                "seatsInfo": this.curSeatCodn.join(","),
                "total": String(this.curArrange.price * this.curSeatCodn.length),
            }

            var formData = new FormData();
            for (var key in options) {
                formData.append(key, options[key]);
            }

            let config = {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }

            axios.post("/api/v1/film/order/insert", formData, config
            ).then( res => {
                console.log(res);
                window.open("http://localhost:8088/pdfjs/web/viewer.html?file=/api/v1/film/order/preview");
            }).catch( res => {
                console.log(res)
            });
        },

        getCurArrangeInfo() {

            if (this.$route.query.aId == undefined) {
                this.$router.push("/");
                return;
            }

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/timeTable/findByModel",
                params: {
                    "id": this.$route.query.aId
                },
            }).then(function(data) {
                if (data.data.data.length == 1) {
                    self.curArrange = data.data.data[0]
                } else {
                    self.$router.push("/");
                }
            }).catch(function (error) {
                console.log(error);
                self.$router.push("/");
            });

        },
        getCurSeatInfo() {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/seat/findByModel",
                params: {
                    "timeId": this.$route.query.aId
                },
            }).then(function(data) {
                if (data.data.data) {
                    var rowArray = data.data.data.row;
                    var colArray = data.data.data.column;
                    for (var i = 0; i < rowArray.length; i++) {
                        
                        var seatCodn = rowArray[i]+"*"+colArray[i];
                        if (self.curDisabledSeatCodn.indexOf(seatCodn) == -1) {
                            self.curDisabledSeatCodn.push(seatCodn);
                        }
                    }
                } else {
                    console.log(data);
                    self.$router.push("/");
                }
            }).catch(function (error) {
                console.log(error);
                self.$router.push("/");
            });
        }
    },
    mounted: function() {
        this.getCurArrangeInfo();
        this.getCurSeatInfo();
    }
}