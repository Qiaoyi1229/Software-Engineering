import axios from 'axios'

import ObeliskMovieMgrCreateModal from "../../../components/obelisk/movie_mgr/obelisk_movie_mgr_create_modal.vue"

export default {
    name: 'ObeliskMovieMgrMainPanel',
    components: {
        ObeliskMovieMgrCreateModal,
    },
    props: {
    },
    data: function() {
        return {
            imgUrlRoot: this.global.BASE_URL,

            filmArray: [],
            mAreaArray: [],
            mTypeArray: [],
            mAreaMap: {},
            mTypeMap: {},

            searchInfo: {},
            curMovie: {},
            
            showMovieOperateModal: false,
        }
    },
    methods: {
        init() {
            this.fetchAllMovieArea();
            this.fetchAllMovieType();
        },
        seachMovieByTypeAndArea() {

            if (!this.searchInfo.typeId) {
                this.$message({
                    message: '请选择电影类型',
                    type: 'warning'
                });
                return;
            }

            if (!this.searchInfo.areaId) {
                this.$message({
                    message: '请选择电影地区',
                    type: 'warning'
                });
                return;
            }

            this.fetchAllMovie();
        },
        fetchAllMovie() {

            var self = this;

            var options = {
                "typeId": Number(this.searchInfo.typeId),
                "areaId": Number(this.searchInfo.areaId),
            }

            axios({
                method: 'post',
                url: "/api/v1/film/film/findByModel",
                params: options,
            }).then(function(data) {
                if (data.data.data) {
                    self.filmArray = data.data.data;
                    self.$message({
                        message: '查询电影成功',
                        type: 'success'
                    });
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        fetchAllMovieArea() {
            
            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/area/findAll",
                params: {}
            }).then(function(data) {
                if (data.data.data) {
                    self.mAreaArray = data.data.data;
                    self.getAreaMap();
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        fetchAllMovieType() {
            
            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/type/findAll",
                params: {}
            }).then(function(data) {
                if (data.data.data) {
                    self.mTypeArray = data.data.data;
                    self.getTypeMap();
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        getTypeMap() {
            for (var type of this.mTypeArray) {
                this.mTypeMap[type.id] = type.name;
            }
        },
        getAreaMap() {
            for (var area of this.mAreaArray) {
                this.mAreaMap[area.id] = area.name;
            }
        },
        movieCardOnClick(movie) {
            this.curMovie = movie
            this.showMovieOperateModal = true;
        },



        addMovieOnClick() {
            this.$refs.createModal.openMovieCreateModal();
        },
        deleteMovieOnClick() {

            this.$confirm('确认删除电影：' + this.curMovie.name, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.deleteMovie(this.curMovie.id);
            });

            this.showMovieOperateModal = false;
        },
        addMovie(options) {

            var self = this;

            var formData = new FormData();
            for (var key in options) {
                formData.append(key, options[key]);
            }

            let config = {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }

            axios.post("/api/v1/film/film/insert", formData, config
            ).then( res => {

                if (res.data.data.length > 0) {
                    self.$message({
                        message: '添加电影成功',
                        type: 'success'
                    });
                    self.fetchAllMovie();
                    self.$refs.createModal.closeMovieCreateModal();
                }
            }).catch( res => {
                self.$message.error('添加电影失败');
                console.log(res)
            });
        },
        deleteMovie(id) {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/film/delete",
                params: {
                    "id": Number(id),
                }
            }).then(function(data) {

                if (data.data.data) {
                    self.$message({
                        message: '删除电影成功',
                        type: 'success'
                    });
                    self.fetchAllMovie();
                }
            }).catch(function (error) {
                self.$message.error('删除电影失败');
                console.log(error);
            });
        }
    },
    mounted: function() {
        this.init();
    }
}