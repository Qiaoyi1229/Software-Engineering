<template>
  <div>

    <el-container>
      <el-header>

        <div style="float: left;">
          <h1 style="margin-top: 10px;">电影网站后台管理系统</h1>
        </div>

        <div class="userAvatarBox">
          <el-avatar icon="el-icon-user-solid userAvatar"></el-avatar>
        </div>
        
      </el-header>

      <el-container>

        <el-aside>

          <el-menu
            :default-active="curPage"
            class="el-menu-vertical-demo">

            <el-menu-item index="1" @click="sideBarItemOnClick('1')">
              <i class="el-icon-user-solid"></i>
              <span slot="title">用户管理</span>
            </el-menu-item>

            <el-menu-item index="2" @click="sideBarItemOnClick('2')">
              <i class="el-icon-video-camera-solid"></i>
              <span slot="title">电影管理</span>
            </el-menu-item>

            <el-menu-item index="3" @click="sideBarItemOnClick('3')">
              <i class="el-icon-s-comment"></i>
              <span slot="title">评论管理</span>
            </el-menu-item>

            <el-submenu index="4">
              <template slot="title">
                <i class="el-icon-s-ticket"></i>
                <span>订单管理</span>
              </template>
              <el-menu-item index="4-1" @click="sideBarItemOnClick('4-1')">订单查询</el-menu-item>
              <el-menu-item index="4-2" @click="sideBarItemOnClick('4-2')">退票审核</el-menu-item>
            </el-submenu>


            <el-menu-item index="5" @click="sideBarItemOnClick('5')">
              <i class="el-icon-menu"></i>
              <span slot="title">场次管理</span>
            </el-menu-item>


            <el-menu-item index="6" @click="sideBarItemOnClick('6')">
              <i class="el-icon-s-data"></i>
              <span slot="title">票房统计</span>
            </el-menu-item>

          </el-menu>

        </el-aside>

        <el-container>
          <el-main>
            <ObeliskUserMgrMainPanel v-show="curPage=='1'" />
            <ObeliskMovieMgrMainPanel v-show="curPage=='2'" />
            <ObeliskCommentMgrMainPanel v-show="curPage=='3'" />

            <ObeliskOrderMgrMainPanel v-show="curPage=='4-1'" />
            <ObeliskRefoundMgrMainPanel v-show="curPage=='4-2'" />

            <ObeliskSeatMgrMainPanel v-show="curPage=='5'" />
            <ObeliskBookingAnalysisMainPanel v-show="curPage=='6'" />
          </el-main>
        </el-container>

      </el-container>

    </el-container>

  </div>
</template>
<script src="../../controller/obelisk/obelisk_root.js"></script>