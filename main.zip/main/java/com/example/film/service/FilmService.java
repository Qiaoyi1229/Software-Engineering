package com.example.film.service;

import com.example.film.doo.FilmDo;
import com.example.film.entity.Film;

import java.util.List;

/**
 * @author 匡婷
 * @version 1.0
 * @date 2020/3/11 17:49
 */
public interface FilmService {

    List<FilmDo> findByModel(Film film);

    Integer insert(Film film);

    Integer update(Film film);

    Integer delete(Integer id);
}
