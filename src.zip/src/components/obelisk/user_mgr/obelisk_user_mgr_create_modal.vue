<template>
  <div>

    <el-dialog title="用户信息" :visible.sync="showUserUpdateModal">
      <el-form label-width="100px" :model="form">
        <el-form-item label="姓名：">
          <el-input v-model="form.name" autocomplete="off" style="width: 90%"></el-input>
        </el-form-item>
        <el-form-item label="年龄：">
          <el-input v-model="form.age" autocomplete="off" style="width: 90%"></el-input>
        </el-form-item>
        <el-form-item label="邮箱：">
          <el-input v-model="form.mail" autocomplete="off" style="width: 90%"></el-input>
        </el-form-item>
        <el-form-item label="电话：">
          <el-input v-model="form.phone" autocomplete="off" style="width: 90%"></el-input>
        </el-form-item>
        <el-form-item label="性别：">
          <template>
            <el-radio v-model="form.sex" label="1">男</el-radio>
            <el-radio v-model="form.sex" label="0">女</el-radio>
          </template>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showUserUpdateModal = false">取 消</el-button>
        <el-button type="primary" @click="updateUserOnClick()">修 改</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<style>
</style>
<script src="../../../controller/obelisk/user_mgr/obelisk_user_mgr_create_modal.js"></script>
