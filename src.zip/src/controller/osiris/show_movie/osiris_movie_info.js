import axios from 'axios'

import OsirisArrangeMovie from "../../../components/osiris/arrange_movie/osiris_arrange_movie.vue"

export default {
    name: 'OsirisMovieInfo',
    components: {
        OsirisArrangeMovie,
    },
    props: {
    },
    data: function() {
        return {
            mainMenuActiveIndex: "2",
            curUserImgUrl: "",

            curMovieObj: {},
        }
    },
    methods: {
        init() {
            this.fetchMovieById();
            this.getCurUserAvatar();
        },
        dateToString(str){
            var date = new Date(str);
            var year = date.getFullYear(); 
            var month =(date.getMonth() + 1).toString(); 
            var day = (date.getDate()).toString();  
            if (month.length == 1) { 
                month = "0" + month; 
            } 
            if (day.length == 1) { 
                day = "0" + day; 
            }
            var dateTime = year + "-" + month + "-" + day;
            return dateTime; 
        },

        userAvatarOnClick() {
            if (!sessionStorage.getItem("name")) {
                this.$router.push("/login");
            }
        },
        getCurUserAvatar() {
            if (sessionStorage.getItem("headIamge")) {
                this.curUserImgUrl = 'http://' + this.global.BASE_URL + sessionStorage.getItem("headIamge");
            }
        },
        handleMainMenuSelect(key) {
            console.log(key);
        },
        

        
        fetchMovieById() {

            if (this.$route.query.movieId == undefined) {
                this.$router.push("/");
                return;
            }

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/film/findByModel",
                params: {
                    "id": self.$route.query.movieId
                },
            }).then(function(data) {
                if (data.data.data) {
                    self.curMovieObj = data.data.data[0];
                    self.setCurMovieImage();
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        setCurMovieImage() {
            document.getElementsByClassName("movieBackImgBox")[0].style.backgroundImage = "url('http://" + this.global.BASE_URL + this.curMovieObj.image + "')";
        }
    },
    mounted: function() {
        this.init();
    }
}