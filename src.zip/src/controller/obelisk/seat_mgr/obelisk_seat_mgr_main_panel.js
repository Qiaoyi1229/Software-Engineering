import axios from 'axios'

import ObeliskSeatMgrCreateModal from "../../../components/obelisk/seat_mgr/obelisk_seat_mgr_create_modal.vue"

export default {
    name: 'ObeliskSeatMgrMainPanel',
    components: {
        ObeliskSeatMgrCreateModal,
    },
    props: {
    },
    data: function() {
        return {
            searchInfo: {},

            movieArray: [],
            hallArray: [],
            arrangeArray: [],
        }
    },
    methods: {
        init() {
            this.fetchAllMovie();
            this.fetchAllHall();
        },
        formatTime(row) {
            return new Date(row.startTime).Format('yyyy-MM-dd hh:mm:ss');
        },
        seachArrangeByMovieId() {

            var self = this;

            if (!self.searchInfo.movieId) {
                this.$message({
                    message: '请选择电影',
                    type: 'warning'
                });
                return;
            }

            axios({
                method: 'post',
                url: "/api/v1/film/timeTable/findByModel",
                params: {
                    "filmId": self.searchInfo.movieId,
                },
            }).then(function(data) {
                if (data.data.data) {
                    self.arrangeArray = data.data.data;
                    self.$message({
                        message: '搜索排片成功',
                        type: 'success'
                    });
                }
            }).catch(function (error) {
                console.log(error);
            });
        },

        fetchAllMovie() {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/film/findByModel",
                params: {},
            }).then(function(data) {
                if (data.data.data) {
                    self.movieArray = data.data.data;
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        fetchAllHall() {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/hall/findAll",
                params: {},
            }).then(function(data) {
                if (data.data.data) {
                    self.hallArray = data.data.data;
                }
            }).catch(function (error) {
                console.log(error);
            });
        },

        seatDeleteOnClick(row) {

            this.$confirm('确认删除排片', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.deleteArrange(row.id);
            });
        },
        addArrangeOnClick() {
            this.$refs.createModal.openArrangeCreateModal();
        },
        addArrange(options) {

            var self = this;

            var formData = new FormData();
            for (var key in options) {
                formData.append(key, options[key]);
            }

            let config = {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }

            axios.post("/api/v1/film/timeTable/insert", formData, config
            ).then( res => {

                if (res.data.data) {
                    self.$message({
                        message: '创建排片成功',
                        type: 'success'
                    });
                    self.seachArrangeByMovieId();
                }
            }).catch( res => {
                self.$message.error('创建排片失败');
                console.log(res)
            });

        },
        deleteArrange(id) {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/timeTable/delete",
                params: {
                    "id": id
                },
            }).then(function(data) {
                if (data.data.data) {
                    self.$message({
                        message: '删除排片成功',
                        type: 'success'
                    });
                    self.seachArrangeByMovieId();
                }
            }).catch(function (error) {
                self.$message.error('删除排片失败');
                console.log(error);
            });
        }
    },
    mounted: function() {
        this.init();

        Date.prototype.Format = function (fmt) {
            var o = {
                "M+": this.getMonth() + 1, 
                "d+": this.getDate(), 
                "h+": this.getHours(),
                "m+": this.getMinutes(),
                "s+": this.getSeconds(),
                "q+": Math.floor((this.getMonth() + 3) / 3),
                "S": this.getMilliseconds()
            };
            if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            for (var k in o)
                if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            return fmt;
        };
    }
}