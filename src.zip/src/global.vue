<script>
    const BASE_URL = "localhost:8088";
    export default {
        BASE_URL,
    }
</script>