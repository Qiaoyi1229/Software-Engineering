<template>
  <div>
      OrderMgr
  </div>
</template>
<script src="../../../controller/obelisk/order_mgr/obelisk_order_mgr_main_panel.js"></script>
