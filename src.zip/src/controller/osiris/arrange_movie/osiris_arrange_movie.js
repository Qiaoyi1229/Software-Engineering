import axios from 'axios'

export default {
    name: 'OsirisArrangeMovie',
    components: {
    },
    props: {
    },
    data: function() {
        return {
            curMovieArrangeArray: []
        }
    },
    methods: {
        init() {
            this.fetchCurArrangeMovie();
        },
        fetchCurArrangeMovie() {
            
            var self = this;

            var options = {
                "filmId": Number(self.$route.query.movieId),
                "startTime": new Date(),
                "endTime": new Date(new Date(new Date().toLocaleDateString()).getTime() + ((24 * 60 * 60 * 1000) * 2) - 1 ),
            }

            var formData = new FormData();
            for (var key in options) {
                formData.append(key, options[key]);
            }

            let config = {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }

            axios.post("/api/v1/film/timeTable/findByModel", formData, config
            ).then( res => {

                if (res.data.data) {
                    self.curMovieArrangeArray = res.data.data;
                }
            }).catch( res => {
                console.log(res)
            });
        },
        arrangeRowOnClick(row) {

            if (!sessionStorage.getItem("name")) {
                this.$message({
                    message: '请登录',
                    type: 'warning'
                });
                this.$router.push("/login");
                return;
            }

            this.$router.push({
                path: '/order',
                query: {
                  "aId": String(row.id),
                }
            });
        }
    },
    mounted: function() {
        this.init();
    }
}