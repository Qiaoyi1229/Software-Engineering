import axios from 'axios'

export default {
    name: 'OsirisShowMovie',
    components: {
    },
    props: {
        row_length: {
            type: Number,
            required: true,
            default: 0,
        },
        row_span: {
            type: Number,
            required: true,
            default: 0,
        }
    },
    data: function() {
        return {
            allMovieArray: [],
            movieArrayForTable: [],
        }
    },
    methods: {
        init() {
            this.fetchAllMovie();
        },
        getMovieImgUrl(url) {
            return 'http://' + this.global.BASE_URL + url;
        },
        fetchAllMovie() {

            var self = this;

            axios({
                method: 'post',
                url: "/api/v1/film/film/findByModel",
                params: {},
            }).then(function(data) {
                if (data.data.data) {
                    self.allMovieArray = data.data.data;
                    self.formatMovieArray(self.allMovieArray);
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        formatMovieArray(movieArray) {
            const iconsArr = [];
            movieArray.forEach((item, index) => {
                const page = Math.floor(index / this.row_length);
                if (!iconsArr[page]) {
                iconsArr[page] = [];
                }
                iconsArr[page].push(item);
            });
            this.movieArrayForTable = iconsArr;
        },
        formatTime(row) {
            return new Date(row).Format('yyyy-MM-dd');
        },

        movieOnClick(movie) {
            this.$router.push({
                path: '/movie',
                query: {
                  "movieId": String(movie.id)
                }
            });
        }
    },
    mounted: function() {
        this.init();

        Date.prototype.Format = function (fmt) {
            var o = {
                "M+": this.getMonth() + 1, 
                "d+": this.getDate(), 
                "h+": this.getHours(),
                "m+": this.getMinutes(),
                "s+": this.getSeconds(),
                "q+": Math.floor((this.getMonth() + 3) / 3),
                "S": this.getMilliseconds()
            };
            if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            for (var k in o)
                if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            return fmt;
        };
    }
}