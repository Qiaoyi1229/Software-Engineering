package com.six.movie.utils;


import com.alibaba.fastjson.JSON;
import com.six.movie.module.BaseResponse;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
@Slf4j
public class ResponseUtil {


    /**
     * 操作成功
     */
    public static final int CODE_SUCCESS = 200;

    /**
     * 系统异常
     */
    public static final int CODE_FAIL = 500;

    /**
     * 内部数据验证失败
     */
    public static final int RUN_FAIL = 106;


    public static BaseResponse success(String message){
        return new BaseResponse(CODE_SUCCESS, message, null);
    }

    public static <T> BaseResponse<T> success(String message, T t){
        return new BaseResponse(CODE_SUCCESS, message, t);
    }

    public static <T> BaseResponse<T> error(String message){
        return new BaseResponse(CODE_FAIL, message, null);
    }

    public static <T> BaseResponse<T> runfail(String message){
        return new BaseResponse(RUN_FAIL, message, null);
    }

    public static void returnJson(HttpServletResponse response, int code, String msg) {
        PrintWriter writer = null;
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=utf-8");
        try {
            writer = response.getWriter();
            writer.print(JSON.toJSONString(new BaseResponse(code, msg, null), true));
        } catch (Exception e) {
            log.error(ExceptionUtil.getExceptionMsg(e));
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

}
