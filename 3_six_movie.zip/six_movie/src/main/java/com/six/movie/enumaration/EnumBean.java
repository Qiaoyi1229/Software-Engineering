package com.six.movie.enumaration;

/**
 * 错误码
 */
public enum EnumBean {
    QUERY_SUCCESS(200, "查询成功"),
    QUERY_WITHOUT_RESULT(201, "查询无结果"),
    ERROR_PARAM(202, "查询参数错误"),
    SYSTEM_EXCEPTION(203, "查询接口地址输入错误或系统异常"),
    QUERY_WITHOUT_PARAM(204, "请至少一个请求参数"),
    QUERY_WITH_ONE_PARAM(205, "等待处理中"),
    QUERY_TOO_MANY_PARAMS(207, "请求参数条数超过30条"),
    TIMEOUT_EXCEPTION(208, "请求超时"),
    INSERT_SUCCESS(250, "添加成功"),
    DELETE_SUCCESS(251, "删除成功"),
    INSERT_ERROR(400, "添加失败"),
    DELETE_ERROR(401, "删除失败"),
    QUERY_ERROR(402, "查询失败");
    private int code;
    private String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    EnumBean(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
