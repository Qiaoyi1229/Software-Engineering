package com.six.movie.service.impl;

import com.six.movie.entity.User;
import com.six.movie.mapper.UserMapper;
import com.six.movie.query.UserQuery;
import com.six.movie.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserMapper userMapper;

    @Override
    public User selectUserByPassword(String userName, String password) {
        User user = userMapper.selectUserByPassword(userName);
        return user;
    }

    @Override
    public Boolean isUserExist(String userName) {
        Long userId = selectUserIdByUserName(userName);
        if(null != userId){
            return true;
        }else{
            return false;
        }
    }


    @Override
    public Long addUser(UserQuery query) {
        userMapper.addUser(query);
        return selectUserIdByUserName(query.getUserName());
    }

    @Override
    public Integer updateUserInfo(UserQuery query) {

        return userMapper.updateUser(query);
    }

    @Override
    public Integer modifyUserPwd(String oldPwd, String newPwd, Integer userId) {
        Integer result = null;
        String password = userMapper.selectPwdByUserId(userId);
        if (null !=password && password.equals(oldPwd)){
            result = userMapper.modifyUserPwd(userId, newPwd);
        }
        return result;
    }

    @Override
    public List<Map<String, Object>> findAllUser() {
        List<Map<String, Object>> result = userMapper.selectAllUser();
        return result;
    }


    public Long selectUserIdByUserName(String userName) {
        return userMapper.selectUserIdByUserName(userName);
    }
}
