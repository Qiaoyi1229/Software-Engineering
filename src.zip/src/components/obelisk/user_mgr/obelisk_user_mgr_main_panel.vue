<template>
  <div>

    <div class="userTabelBox">
      <el-table
        :data="userArray"
        style="width: 100%">

        <el-table-column
          width="60"
          prop="id"
          label="编号">
        </el-table-column>
        
        <el-table-column
          width="120"
          prop="name"
          label="姓名">
        </el-table-column>

        <el-table-column
          width="150"
          prop="phone"
          label="电话">
        </el-table-column>

        <el-table-column
          width="250"
          prop="mail"
          label="邮箱">
        </el-table-column>

        <el-table-column
          width="100"
          prop="age"
          label="年龄">
        </el-table-column>

        <el-table-column
          width="100"
          prop="sex"
          :formatter="formatSex"
          label="性别">
        </el-table-column>

        <el-table-column
          width="250"
          prop="createTime"
          :formatter="formatTime"
          label="注册时间">
        </el-table-column>

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button @click="userDeleteOnClick(scope.row)" type="text" size="small">删除</el-button>
            <el-button @click="userUpdateOnClick(scope.row)" type="text" size="small">编辑</el-button>
          </template>
        </el-table-column>

      </el-table>
    </div>

    <ObeliskUserMgrCreateModal 
      ref="createModal" 
      @update_user="updateUser"/>
    
  </div>
</template>
<style>
  .userTabelBox {
    margin: 20px;
  }
</style>
<script src="../../../controller/obelisk/user_mgr/obelisk_user_mgr_main_panel.js"></script>
