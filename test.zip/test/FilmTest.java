package com.example.film.test;

import com.example.film.doo.FilmDo;
import com.example.film.entity.Film;
import com.example.film.entity.User;
import com.example.film.service.FilmService;
import com.example.film.service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.DigestUtils;

import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest
public class FilmTest {

    @Autowired
    FilmService filmService;

    @Test
    public void findAll() {
        List<FilmDo> filmDos = filmService.findByModel(new Film());
        for (FilmDo item : filmDos
        ) {
            System.out.println(item.getName());
        }
    }
}
