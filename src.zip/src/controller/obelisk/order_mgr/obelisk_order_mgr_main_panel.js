export default {
    name: 'ObeliskOrderMgrMainPanel',
    props: {
    },
    data: function() {
        return {
            test: 3,
        }
    }
}