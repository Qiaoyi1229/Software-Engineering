import Vue from 'vue'
import VueRouter from 'vue-router'

import Obelisk from "./components/obelisk/obelisk_root.vue"
import Osiris from "./components/osiris/osiris_root.vue"
import OsirisLogin from "./components/osiris/osiris_login.vue"
import OsirisMovie from "./components/osiris/show_movie/osiris_movie_info.vue"
import OsirisOrder from "./components/osiris/movie_order/osiris_movie_order.vue"

Vue.use(VueRouter)

export default new VueRouter({
    mode: 'history',
    routes: [
        {
            path: "/manager",
            component: Obelisk,
        },
        {
            path: "/",
            component: Osiris,
        },
        {
            path: "/login",
            component: OsirisLogin,
        },
        {
            path: "/movie",
            component: OsirisMovie,
        },
        {
            path: "/order",
            component: OsirisOrder,
        },
    ]
});