import ObeliskUserMgrMainPanel from "../../components/obelisk/user_mgr/obelisk_user_mgr_main_panel.vue"
import ObeliskSeatMgrMainPanel from "../../components/obelisk/seat_mgr/obelisk_seat_mgr_main_panel.vue"
import ObeliskOrderMgrMainPanel from "../../components/obelisk/order_mgr/obelisk_order_mgr_main_panel.vue"
import ObeliskMovieMgrMainPanel from "../../components/obelisk/movie_mgr/obelisk_movie_mgr_main_panel.vue"
import ObeliskCommentMgrMainPanel from "../../components/obelisk/comment_mgr/obelisk_comment_mgr_main_panel.vue"
import ObeliskBookingAnalysisMainPanel from "../../components/obelisk/booking_analysis/obelisk_booking_analysis_main_panel.vue"
import ObeliskRefoundMgrMainPanel from "../../components/obelisk/refound_mgr/obelisk_refound_mgr_main_panel.vue"

export default {
    name: 'ObeliskRoot',
    components: {
        ObeliskUserMgrMainPanel,
        ObeliskSeatMgrMainPanel,
        ObeliskOrderMgrMainPanel,
        ObeliskMovieMgrMainPanel,
        ObeliskCommentMgrMainPanel,
        ObeliskBookingAnalysisMainPanel,
        ObeliskRefoundMgrMainPanel,
    },
    props: {
    },
    data: function() {
        return {
            curPage: "1",
        }
    },
    methods: {
        sideBarItemOnClick(index) {
            this.curPage = index;
        },
    },
}