<template>
  <div>

    <el-container>


      <el-header>
        <div class="pageHead">
          <h1>XXXX</h1>
        </div>

        <div class="userAvatarBox">
          <el-avatar :src="curUserImgUrl"
            icon="el-icon-user-solid userAvatar" @click.native="userAvatarOnClick()"></el-avatar>
        </div>

        <el-menu :default-active="mainMenuActiveIndex" class="mainMenu" mode="horizontal" @select="handleMainMenuSelect">
          <el-menu-item index="1">主页</el-menu-item>
          <el-menu-item index="2">影片</el-menu-item>
          <el-menu-item index="3">影院</el-menu-item>
        </el-menu>
      </el-header>



      <el-main>

        <el-carousel indicator-position="none" height="400px">
          <el-carousel-item>
            <img src="../../assets/c_1.jpg" class="carousel_image_type">
          </el-carousel-item>
          <el-carousel-item>
            <img src="../../assets/c_2.jpg" class="carousel_image_type">
          </el-carousel-item>
          <el-carousel-item>
            <img src="../../assets/c_3.jpg" class="carousel_image_type">
          </el-carousel-item>
        </el-carousel>

        <div class="mainShowMovieBox">

          <div class="showMovieTitleBox">
            最近热映
          </div>

          <OsirisShowMovie :row_length="3" :row_span="8" />
        </div>

      </el-main>
      
      
      
      <el-footer></el-footer>
    </el-container>

  </div>
</template>
<style>
  * {
    margin: 0;
    padding: 0;
  }
  .el-header, .el-footer {
    background-color: #409EFF;
    color: #ffffff;
  }
  .pageHead {
    margin-top: 15px;
    margin-left: 10%;
    float: left;
  }

  .mainMenu {
    width: 60%;
    margin-left: 20%;
  }
  .userAvatarBox {
    float: right;
    margin-top: 10px;
  }
  .userAvatar:hover {
    cursor: pointer;
  }

  .carousel_image_type{
    width: 100%;
  }

  .mainShowMovieBox {
    padding-top: 50px;
    width: 70%;
    margin: 0 auto;
  }

  .showMovieTitleBox {
    font: 50px Extra large sans-serif;
  }
</style>
<script src="../../controller/osiris/osiris_root.js"></script>