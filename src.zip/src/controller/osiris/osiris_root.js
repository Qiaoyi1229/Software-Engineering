
import OsirisShowMovie from "../../components/osiris/show_movie/osiris_show_movie.vue"

export default {
    name: 'OsirisRoot',
    components: {
        OsirisShowMovie,
    },
    props: {
    },
    data: function() {
        return {
            mainMenuActiveIndex: '1',

            curUserImgUrl: "",
        }
    },
    methods: {
        handleMainMenuSelect(key) {
            console.log(key);
        },
        userAvatarOnClick() {
            if (!sessionStorage.getItem("name")) {
                this.$router.push("/login");
            }
        },
        getCurUserAvatar() {
            if (sessionStorage.getItem("headIamge")) {
                this.curUserImgUrl = 'http://' + this.global.BASE_URL + sessionStorage.getItem("headIamge");
            }
        }
    },
    mounted: function() {
        this.getCurUserAvatar();
    }
}