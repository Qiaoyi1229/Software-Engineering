export default {
    name: 'ObeliskUserMgrCreateModal',
    props: {
        
    },
    data: function() {
        return {
            showUserUpdateModal: false,
            form: {},
        }
    },
    methods: {
        openUserCreateModal(user) {
            this.form = {
                id: user.id,
                age: user.age,
                mail: user.mail,
                name: user.name,
                phone: user.phone,
                sex: String(user.sex),
            }
            this.showUserUpdateModal = true;
        },
        updateUserOnClick() {

            if (this.form.name == "") {
                this.$message({
                    message: '请输入姓名',
                    type: 'warning'
                });
            }

            if (this.form.age == "" || isNaN(this.form.age)) {
                this.$message({
                    message: '请输入正确的年龄',
                    type: 'warning'
                });
            }

            if (this.form.mail == "") {
                this.$message({
                    message: '请输入邮箱',
                    type: 'warning'
                });
            }

            if (this.form.phone == "") {
                this.$message({
                    message: '请输入电话',
                    type: 'warning'
                });
            }

            if (this.form.sex == "" || isNaN(this.form.sex)) {
                this.$message({
                    message: '请选择性别',
                    type: 'warning'
                });
            }

            this.$emit("update_user", this.form);
            this.showUserUpdateModal = false;
        }
    },
    mounted: function() {
    }
}