<template>
  <div>
      bookingAnalysis
  </div>
</template>
<script src="../../../controller/obelisk/booking_analysis/obelisk_booking_analysis_main_panel.js"></script>
