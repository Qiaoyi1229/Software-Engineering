<template>
  <div>

    <div class="seachMovieBox">
      <el-select v-model="searchInfo.movieId" placeholder="请选择要查询的电影">
        <el-option
          v-for="item in movieArray"
          :key="item.id"
          :label="item.name"
          :value="item.id">
        </el-option>
      </el-select>

      <div style="float: right">
        <el-button type="primary" @click="seachArrangeByMovieId()">搜索当前电影排片</el-button>
      </div>
    </div>

    <div class="arrangeTabelBox">
      <el-table
        :data="arrangeArray"
        style="width: 100%">

        <el-table-column
          width="250"
          prop="filmName"
          label="电影名称">
        </el-table-column>
        
        <el-table-column
          width="120"
          prop="hallName"
          label="大厅">
        </el-table-column>

        <el-table-column
          width="150"
          prop="price"
          label="票价">
        </el-table-column>

        <el-table-column
          width="500"
          prop="startTime"
          :formatter="formatTime"
          label="开场时间">
        </el-table-column>

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button @click="seatDeleteOnClick(scope.row)" type="text" size="small">删除</el-button>
          </template>
        </el-table-column>

      </el-table>
    </div>

    <el-card class="arrangeInsertIconBox" shadow="hover" @click.native="addArrangeOnClick()">
      <i class="el-icon-circle-plus-outline insertMovieIcon"></i>
    </el-card>

    <ObeliskSeatMgrCreateModal 
      ref="createModal"
      :movie_array="movieArray"
      :hall_array="hallArray"
      @add_arrange="addArrange" />

  </div>
</template>
<style>
  .arrangeTabelBox {
    margin: 20px;
  }
  .arrangeInsertIconBox {
    width: 97%;
    margin: 0 auto;
    font-size: 35px;
    margin-top: 30px;
    text-align: center;
  }
  .arrangeInsertIconBox:hover {
    cursor: pointer;
  }
</style>
<script src="../../../controller/obelisk/seat_mgr/obelisk_seat_mgr_main_panel.js"></script>
