export default {
    name: 'ObeliskBookingMgrMainPanel',
    props: {
    },
    data: function() {
        return {
            test: 3,
        }
    }
}