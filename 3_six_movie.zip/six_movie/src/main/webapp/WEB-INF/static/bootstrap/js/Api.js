var urlHead = "http://localhost.";

var urlFoot = ":8080/Movie_war";

var url = urlHead.toString() + urlFoot.toString();